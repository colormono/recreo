package Turtle;

public class penStates {
	public static int PENDOWN = 0;
	public static int PENUP = 1;
	public static int FILLED = 2;
	public static int PENFAT = 3;
}